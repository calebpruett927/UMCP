#!/usr/bin/env python3
"""UMCP minimal compute: given a CSV with columns t (int/float) and x (float),
compute the invariant kernel (omega,F,S,C,tau_R,IC,kappa) using frozen (a,b,epsilon)
from freeze_contract.json. Outputs out.csv by default.

Usage:
  python umcp_compute_min.py --csv input.csv --out out.csv [--K 3] [--alpha 1.0]

Assumptions:
  - Normalization mode: global_fixed with (a,b) from freeze_contract.json.
  - Drift policy: pre_clip (omega = |Δy|); near-wall pivot not auto-enabled here.
  - epsilon_ret policy for tau_R uses EMA of |Δxhat| with defaults in this script.

This script is intentionally compact for portability. For multi-channel or weld checks,
use collapse_validate.py and your full stacks.
"""

import csv, math, argparse, json, os
from collections import deque

def load_freeze(path):
    with open(path, 'r') as f:
        data = json.load(f)
    a = float(data['a'])
    b = float(data['b'])
    eps = float(data.get('epsilon', 1e-8))
    return a, b, eps

def ema(prev, x, lam):
    if prev is None:
        return x
    return lam * x + (1.0 - lam) * prev

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--csv', required=True, help='input CSV with columns: t,x')
    ap.add_argument('--out', default='out.csv')
    ap.add_argument('--freeze', default='freeze_contract.json')
    ap.add_argument('--K', type=int, default=3)
    ap.add_argument('--alpha', type=float, default=1.0)
    # tau_R policy knobs (kept here for full determinism of the portable pack)
    ap.add_argument('--ema_lambda', type=float, default=0.2)
    ap.add_argument('--k_ret', type=float, default=2.5)
    ap.add_argument('--eps_min', type=float, default=5e-4)
    ap.add_argument('--eps_max', type=float, default=7e-2)
    ap.add_argument('--L', type=int, default=2)           # debounce
    ap.add_argument('--H_max', type=int, default=600)     # horizon (rows)
    args = ap.parse_args()

    a,b,epsilon = load_freeze(args.freeze)
    rows = []
    with open(args.csv, 'r', newline='') as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append({'t': float(row['t']), 'x': float(row['x'])})

    # compute
    out = []
    xhat_hist = deque(maxlen=args.K)
    omega_prev = None
    ema_sigma = None
    last_tau_hit = 0
    for i, row in enumerate(rows):
        x = row['x']
        y = (x - a) / b
        xhat = min(1.0, max(0.0, y))

        if i == 0:
            omega = 0.0
        else:
            y_prev = (rows[i-1]['x'] - a) / b
            omega = abs(y - y_prev)

        F = 1.0 - omega
        S = -math.log(max(1e-300, 1.0 - omega + epsilon))

        # curvature
        xhat_hist.append(xhat)
        if i < args.K:
            C = 0.0
        else:
            # mean of squared differences to the last K steps
            acc = 0.0
            for k in range(1, args.K+1):
                xhat_k = min(1.0, max(0.0, (rows[i-k]['x'] - a)/b))
                acc += (xhat - xhat_k) ** 2
            C = acc / args.K

        # tau_R via epsilon_ret policy with EMA of |Δxhat|
        if i == 0:
            dxhat = 0.0
        else:
            xhat_prev = min(1.0, max(0.0, (rows[i-1]['x'] - a)/b))
            dxhat = abs(xhat - xhat_prev)

        ema_sigma = ema(ema_sigma, dxhat, args.ema_lambda)
        if ema_sigma is None:
            ema_sigma = dxhat

        eps_ret = min(max(args.k_ret * ema_sigma, args.eps_min), args.eps_max)

        # search back up to H_max for a re-entry within eps_ret, with debounce L
        tau_R = 1.0
        found = False
        for dt in range(1, min(args.H_max, i) + 1):
            xhat_back = min(1.0, max(0.0, (rows[i-dt]['x'] - a)/b))
            if abs(xhat - xhat_back) < eps_ret:
                # debounce: require L consecutive near matches
                ok = True
                for j in range(1, args.L+1):
                    if i-dt-j < 0: break
                    xhb = min(1.0, max(0.0, (rows[i-dt-j]['x'] - a)/b))
                    if abs(xhat - xhb) >= eps_ret:
                        ok = False
                        break
                if ok:
                    tau_R = float(dt)
                    found = True
                    break
        if not found and i == 0:
            tau_R = 1.0

        IC = F * math.exp(-S) * (1.0 - omega) * math.exp(-args.alpha * C / (1.0 + tau_R))
        IC = max(1e-300, min(1.0, IC))
        kappa = math.log(IC)

        out.append({
            't': row['t'],
            'x': x,
            'y': y,
            'xhat': xhat,
            'omega': omega,
            'F': F,
            'S': S,
            'C': C,
            'tau_R': tau_R,
            'IC': IC,
            'kappa': kappa
        })

    with open(args.out, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)

if __name__ == '__main__':
    main()
