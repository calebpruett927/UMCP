UMCP / RCFT — Proof Pack v1 (minimal)
Tags present: UMCP–EQ–001..003,004,005,006,007,008,010,011,012.
Statements + proof sketches as per prior packages.
