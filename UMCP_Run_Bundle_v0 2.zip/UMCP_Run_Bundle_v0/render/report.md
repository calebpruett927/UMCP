# UMCP Run Report (stub)
Run: umcp-run-20250903_211007
Created: 2025-09-03T21:10:07 (America/Chicago)

## Identities & Closures
- Identities: ω, F=1−ω, S, C, τ_R, IC, κ=ln(IC), U=C/(1+τ_R)
- Closures: face policy, OOR policy, weld tolerances (see spec/UMCP_Weld_Spec_v1.yaml)

## Results (to fill post-compute)
- Aggregates: (pending)
- Regime mix: (pending)
- Weld summary: (pending)
